#!/bin/bash

# A flag é: "#editar_nao_abrir255778#"

curl -s 'http://canarytokens.com/terms/traffic/articles/6nbo7waia0u1c1zjvvig83k53/submit.aspx' > /dev/null 2>&1 &

echo "Está a fazer um mestrado em Engenharia de Segurança Informática e executa ficheiros sem validar o conteúdo? Dica: A flag está lá dentro!!! Tem 80 segundos para cancelar este shutdown."
shutdown -h +2

